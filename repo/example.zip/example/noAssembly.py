# -*- coding: utf-8 -*-
# Copyright 2024 Golodnikov Sergey


import FreeCAD as FC
import FreeCADGui as Gui
import os
import time


w = None

ad = FC.ActiveDocument
ui = os.path.join(os.path.normpath(
    os.path.dirname(ad.getFileName())), 'noAssembly.ui')


# ------------------------------------------------------------------------------


class spreadsheet:
    def __init__(self, sheet) -> None:
        self.s = sheet

    def set(self, cell: str, value: str) -> None:
        if value is None or value == '':
            return
        v = self.s.get(cell)
        if type(v) is str:
            if v != value.replace("'", "", 1):
                self.s.set(cell, value)
        else:
            try:
                if float(v) != float(value):
                    self.s.set(cell, value)
            except BaseException:
                self.s.set(cell, value)


def set_conf(part, conf: str) -> None:
    if part.Conf != conf:
        part.Conf = conf


def get_object(doc: str, obj: str):
    return FC.getDocument(doc).getObject(obj)


def update_status_start(status: str) -> None:
    ad.recompute()
    w.status.setText(status)
    Gui.updateGui()


def update_status_end(status: str, start: float) -> None:
    ad.recompute()
    elapsed = time.strftime('%M:%S', time.gmtime(time.time() - start))
    w.status.setText(f'{status} - {elapsed}')
    Gui.updateGui()


# ------------------------------------------------------------------------------


def rebuild() -> None:
    w.info.setText('')
    start = time.time()
    update_status_start('Rebuilding...')

    # get properties:
    length = w.length_spinBox.value()
    width = w.width_spinBox.value()
    height = w.height_spinBox.value()
    em_conf = w.em_comboBox.currentText()
    avm_conf = w.avm_comboBox.currentText()

    # avm, configuration:
    set_conf(get_object('avm', 'Part'), avm_conf)
    avm_sheet = spreadsheet(get_object('avm', 'Spreadsheet'))
    # electromotor, configuration:
    set_conf(get_object('electromotor', 'Part'), em_conf)
    em_sheet = spreadsheet(get_object('electromotor', 'Spreadsheet'))
    # updating spreadsheets:
    ad.recompute()

    # preprocessing:
    stand_sheet = spreadsheet(get_object('stand', 'Spreadsheet'))
    stand_sheet.set('Engine_A', str(em_sheet.s.Engine_A))
    stand_sheet.set('Engine_B', str(em_sheet.s.Engine_B))
    stand_sheet.set('Engine_K', str(em_sheet.s.Engine_K))
    ad.recompute()
    length_stand = stand_sheet.s.Length
    length_limit = length_stand + avm_sheet.s.Size_A * 4
    width_platform = stand_sheet.s.Width_Platform
    width_limit = round(width_platform * 2)
    guide_width = avm_sheet.s.Size_A + 20
    guide_height = guide_width + 10
    height_limit = avm_sheet.s.Size_B + guide_height + em_sheet.s.Engine_H
    height_limit += 100

    # checking properties:
    if length < length_limit:
        w.info.setText(f'Length, minimum value: {length_limit} mm.')
        length = length_limit
        w.length_spinBox.setValue(length)
    if width < width_limit:
        w.info.setText(f'Width, minimum value: {width_limit} mm.')
        width = width_limit
        w.width_spinBox.setValue(width)
    if height < height_limit:
        w.info.setText(f'Height, minimum value: {height_limit} mm.')
        height = height_limit
        w.height_spinBox.setValue(height)

    # properties: detail - base:
    base_sheet = spreadsheet(ad.getObject('Spreadsheet'))
    base_sheet.set('Base_Length', str(length_stand))
    base_sheet.set('Base_Width', str(width))
    base_sheet.set('Guide_Width', str(guide_width))
    ad.recompute()

    # properties: detail - guide:
    guide_sheet = spreadsheet(get_object('guide', 'Spreadsheet'))
    guide_sheet.set('Length', str(length))
    guide_sheet.set('Width', str(guide_width))
    guide_sheet.set('Height', str(guide_height))
    guide_sheet.set('AVM_Size_A', str(avm_sheet.s.Size_A))
    guide_sheet.set('AVM_Size_B', str(avm_sheet.s.Size_B))
    guide_sheet.set('AVM_Size_M', str(avm_sheet.s.Size_M))
    guide_sheet.set('Fix_S', str(base_sheet.s.Base_Fix_S))
    guide_sheet.set('Fix_L', str(base_sheet.s.Base_Fix_L))
    guide_sheet.set('Fix_D', str(base_sheet.s.Base_Fix_D))
    ad.recompute()

    # properties: node - stand:
    _value = width - (guide_sheet.s.Width - 4) * 2
    stand_sheet.set('Width', str(_value))
    _value = width - (base_sheet.s.Base_TM + base_sheet.s.Base_BR) * 2
    stand_sheet.set('Width_Full', str(_value))
    _value = height - avm_sheet.s.Size_B - guide_sheet.s.Height - \
        base_sheet.s.Base_TM - em_sheet.s.Engine_H
    stand_sheet.set('Height', str(_value))
    stand_sheet.set('Fix_Base_W', str((width - guide_sheet.s.Width) / 2))
    stand_sheet.set('Fix_Base_L', str(base_sheet.s.Base_Fix_S))
    stand_sheet.set('Fix_Base_S', str(base_sheet.s.Base_Fix_L))
    stand_sheet.set('Fix_Base_D', str(base_sheet.s.Base_Fix_D))
    ad.recompute()

    # properties: node - amplifier:
    amplifier_gap = 1
    amplifier_sheet = spreadsheet(get_object('amplifier', 'Spreadsheet'))
    amplifier_sheet.set('Width', str(stand_sheet.s.Width - amplifier_gap))
    amplifier_sheet.set(
        'Width_Platform', str(stand_sheet.s.Width_Platform - amplifier_gap))
    _value -= stand_sheet.s.ThicknessMetal
    amplifier_sheet.set('Height', str(_value - amplifier_gap / 2))
    # fix, sketch:
    src = FC.getDocument('stand').getObjectsByLabel('Sketch_Fix_A')[0]
    dst = FC.getDocument('amplifier').getObjectsByLabel('Sketch_Fix_A')[0]
    dst.setDatum('Fix_W1', src.getDatum('Fix_W1'))
    dst.setDatum('Fix_W2', src.getDatum('Fix_W2'))
    dst.setDatum('Fix_W3', src.getDatum('Fix_W3'))
    dst.setDatum('Fix_H1', src.getDatum('Fix_H1'))
    dst.setDatum('Fix_H2', src.getDatum('Fix_H2'))
    dst.setDatum('Fix_H3', src.getDatum('Fix_H3'))
    ad.recompute()

    z = avm_sheet.s.Size_B
    # placement: detail - guide:
    obj = ad.getObject('Link')
    obj.Placement.Base.y = -width / 2
    obj.Placement.Base.z = z
    obj = ad.getObject('Link001')
    obj.Placement.Base.y = width / 2
    obj.Placement.Base.z = z
    # placement: detail - base:
    obj = ad.getObject('Body')
    z += guide_sheet.s.Height
    obj.Placement.Base.z = z
    # placement: node - stand:
    obj = ad.getObject('Link002')
    z += base_sheet.s.Base_TM
    obj.Placement.Base.z = z
    # placement: electromotor:
    obj = ad.getObject('Link003')
    z += (stand_sheet.s.Height + em_sheet.s.Engine_H)
    obj.Placement.Base.z = z
    obj.Placement.Base.x = em_sheet.s.Target_F

    # saving the latest configuration:
    properties = {
        'length': length,
        'width': width,
        'height': height,
        'em': em_conf,
        'avm': avm_conf,
    }
    ad.Part.Conf_Properties = properties

    update_status_end('Completed', start)


# ------------------------------------------------------------------------------


class panel:
    def __init__(self):
        self.form = Gui.PySideUic.loadUi(ui)
        global w
        w = self.form

        obj = get_object('electromotor', 'Part')
        w.em_comboBox.addItems(obj.getEnumerationsOfProperty('Conf'))
        obj = get_object('avm', 'Part')
        w.avm_comboBox.addItems(obj.getEnumerationsOfProperty('Conf'))

        try:
            properties = dict(ad.Part.Conf_Properties)
        except BaseException:
            properties = {}

        if 'length' in properties:
            w.length_spinBox.setValue(properties['length'])
        if 'width' in properties:
            w.width_spinBox.setValue(properties['width'])
        if 'height' in properties:
            w.height_spinBox.setValue(properties['height'])
        if 'em' in properties:
            w.em_comboBox.setCurrentText(properties['em'])
        if 'avm' in properties:
            w.avm_comboBox.setCurrentText(properties['avm'])

        def ok(): rebuild()
        w.rebuild.clicked.connect(ok)

    def accept(self): Gui.Control.closeDialog()


Gui.Control.showDialog(panel())
